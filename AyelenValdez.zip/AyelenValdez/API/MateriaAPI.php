<?php
include_once("Entidades/token.php");
include_once("Entidades/materia.php");
//include_once("Entidades/foto.php");

class MateriaAPI extends Materia
{
   /* public function RegistrarCompraFoto($request, $response, $args)
    {
        $parametros = $request->getParsedBody();

        $files = $request->getUploadedFiles();
        $articulo = $parametros["articulo"];
        $precio = $parametros["precio"];
        $fecha = $parametros["fecha"];
        $fecha = date('Y-m-d H:i:s');
        $token = $request->getHeaderLine('token');

        $foto = $files["foto"];
        //Consigo la extensión de la foto.  
        $ext = Foto::ObtenerExtension($foto);
        if ($ext != "ERROR") {
            //Genero el nombre de la foto.
            $nombreFoto = $articulo . "_Foto" . $ext;

            //Guardo la foto.
            $rutaFoto = "./IMGCompras/" . $nombreFoto;
            Foto::GuardarFoto($foto, $rutaFoto);

            $respuesta = "Insertado Correctamente.";
            Compra::Insertar($articulo, $precio, $fecha, $nombreFoto, $token);
            $newResponse = $response->withJson($respuesta, 200);
            return $newResponse;
        } else {
            $respuesta = "Ocurrio un error.";
            $newResponse = $response->withJson($respuesta, 200);
            return $newResponse;
        }
    }*/

    public function RegistrarMateria($request, $response, $args)
    {
        $parametros = $request->getParsedBody();

        $nombre = $parametros["nombre"];
        $cupos = $parametros["cupos"];
        $cuatrimestre = $parametros["cuatrimestre"];

        $respuesta = Materia::Insertar($nombre, $cuatrimestre, $cupos);
        $newResponse = $response->withJson($respuesta, 200);
        return $newResponse;
    }


    public function Listar1($request, $response, $args)
    {    
        $token = $request->getHeaderLine('token');
        $todos = Materia::Listar($token);

        $newResponse = $response->withJson($todos, 200);
        return $newResponse;
    }
}
?>
