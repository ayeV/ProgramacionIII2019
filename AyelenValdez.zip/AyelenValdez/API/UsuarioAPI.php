<?php
include_once("Entidades/token.php");
include_once("Entidades/usuario.php");
include_once("Entidades/foto.php");

class UsuarioAPI extends Usuario
{  
    public function RegistrarUsuario($request, $response, $args)
    {
        echo('USUARIOAPI');
        $parametros = $request->getParsedBody();
        $clave = $parametros["clave"];
        $nombre = $parametros["nombre"];
        $tipo = $parametros["tipo"];

        $respuesta = Usuario::Registrar($nombre, $clave, $tipo);
        $newResponse = $response->withJson($respuesta, 200);
        return $newResponse;
    }

    public function LoginUsuario($request, $response, $args)
    {
        $parametros = $request->getParsedBody();
        $legajo = $parametros["legajo"];
        $clave = $parametros["clave"];

        $retorno = Usuario::Login($legajo, $clave);
        if ($retorno) {
            if($retorno->legajo == $legajo && $retorno->clave == $clave){

             $token = Token::CodificarToken($retorno->legajo, $retorno->clave, $retorno->tipo);
            
            $respuesta = array("Estado" => "OK", "Mensaje" => "Logueado exitosamente.", "Token" => $token, "Nombre" => $retorno->nombre);
            }
            else
              $respuesta = array("Estado" => "ERROR", "Mensaje" => "Legajo o clave invalido");

         
        } else {
            $respuesta = array("Estado" => "ERROR", "Mensaje" => "Usuario invalidos.");
        }
                $newResponse = $response->withJson($respuesta, 200);

        return $newResponse;
    }   
  
    public function ListarUsuarios($request, $response, $args)
    {
        $respuesta = Usuario::Listar();
        $newResponse = $response->withJson($respuesta, 200);
        return $newResponse;
    }
  

    public function ModificarUsuario($request, $response, $args)
    {
        $parametros = $request->getParsedBody();

      
        $token = $request->getHeaderLine('token');
        $payload = Token::ObtenerPayload($token);
        $legajo = $args["legajo"];
        $email = $parametros["email"];
        //$files = $request->getUploadedFiles();
        //$foto = $files["foto"];

       
            if($payload->tipo == 'alumno'){
                /*$ext = Foto::ObtenerExtension($foto);
                    $nombreFoto = $legajo . "_Foto" . $ext;
        
                    //Guardo la foto.
                    $rutaFoto = "./IMGCompras/" . $nombreFoto;
                    Foto::GuardarFoto($foto, $rutaFoto);*/
        
                    $respuesta = "Insertado Correctamente.";
                $respuesta = Usuario::Modificar($legajo, $email, null,$token);

            }
            else if($payload->tipo == 'profesor')
            {
                $id_materia = $parametros["id_materia"];

                $respuesta = Usuario::Modificar($legajo, $email, null,$token,$id_materia);

            }
            $newResponse = $response->withJson($respuesta, 200);
            return $newResponse;



        $respuesta = Usuario::Modificar($legajo, $email, $foto);
        $newResponse = $response->withJson($respuesta, 200);
        return $newResponse;
    }

    public function InscripcionMateria($request, $response, $args)
    {

        $token = $request->getHeaderLine('token');
       
        $id_materia = $args["id_materia"];
        $respuesta = Usuario::Inscripcion($token,$id_materia);
        $newResponse = $response->withJson($respuesta, 200);
        return $newResponse;
     
    }
 
}
    ?>