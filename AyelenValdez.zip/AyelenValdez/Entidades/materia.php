<?php
include_once("DB/AccesoDatos.php");
include_once("Entidades/token.php");

class Materia
{
    public $nombre;
    public $cuatrimestre;
    public $cupo;
    public $id_materia;
    public $legajo_user;
    


    /*public function __toString()
    {
        return $this->id_compra." - ".$this->articulo." - ".$this->precio." - ".$this->foto."-".$this->fecha;
    }*/
    public static function Listar($token)
    {
        try {
            $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
            $payload = Token::ObtenerPayLoad($token);
            $perfil = $payload->perfil;
            $id_user = $payload->id;
            
            if ($perfil == "Usuario") {
                $consulta = $objetoAccesoDato->RetornarConsulta("SELECT c.articulo, c.precio, c.foto,c.id_compra,c.id_user,c.fecha
                                                            FROM compras c WHERE c.id_user = :id_user;");

                $consulta->bindValue(':id_user', $id_user, PDO::PARAM_INT);

            } else {
                $consulta = $objetoAccesoDato->RetornarConsulta("SELECT * from compras;");
            }


            $consulta->execute();

            $respuesta = $consulta->fetchAll(PDO::FETCH_CLASS, "Compra");
        } catch (Exception $e) {
            $mensaje = $e->getMessage();
            $respuesta = array("Estado" => "ERROR", "Mensaje" => "$mensaje");
        } finally {
            return $respuesta;
        }
    }





    public static function Insertar($nombre, $cuatrimestre, $cupos)
    {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();

        $respuesta = "";
        try {

        
            
            $consulta = $objetoAccesoDato->RetornarConsulta("INSERT INTO materias (cuatrimestre, cupos,nombre)
                VALUES(:cuatrimestre, :cupos, :nombre)");


            $consulta->bindValue(':cuatrimestre', $cuatrimestre, PDO::PARAM_INT);
            $consulta->bindValue(':cupos', $cupos, PDO::PARAM_INT);
            $consulta->bindValue(':nombre', $nombre, PDO::PARAM_STR);
          //  $consulta->bindValue(':legajo_user', $legajo_user, PDO::PARAM_INT);
            $consulta->execute();
            $respuesta = array("Estado" => "OK", "Mensaje" => "Materia registrada correctamente.");
        } catch (Exception $e) {
            $mensaje = $e->getMessage();
            $respuesta = array("Estado" => "ERROR", "Mensaje" => "$mensaje");
        } finally {
            return $respuesta;
        }
    }
}
