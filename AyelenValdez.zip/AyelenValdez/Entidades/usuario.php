<?php
include_once("DB/AccesoDatos.php");
class Usuario
{
    public $legajo;
    public $nombre;
    public $clave;
    public $tipo;
    public $email;
    public $foto;
    public $id_materia;
    public static function Registrar($nombre, $clave, $tipo)
    {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
        $respuesta = "";
        try {
            echo ('Usuario.PHP');
            //Si el perfil es disinto de null entonces va a ser admin
            if($tipo == "alumno")
            {
                $consulta = $objetoAccesoDato->RetornarConsulta("INSERT INTO usuarios (nombre, tipo, clave) 
                VALUES (:nombre, 'alumno', :clave);");
               

            }
            else if($tipo == "profesor")
            {
                $consulta = $objetoAccesoDato->RetornarConsulta("INSERT INTO usuarios (nombre, tipo, clave) 
                VALUES (:nombre, 'profesor', :clave);");
               
            }
            else if($tipo == "admin")
            {
                $consulta = $objetoAccesoDato->RetornarConsulta("INSERT INTO usuarios (nombre, tipo, clave) 
                VALUES (:nombre, 'admin', :clave);");
               
            }
            else
            {
                $respuesta = array("Estado" => "Error", "Mensaje" => "El tipo de usuario debe ser admin, profesor o alumno.");

            }
               
                $consulta->bindValue(':nombre', $nombre, PDO::PARAM_STR);
                $consulta->bindValue(':clave', $clave, PDO::PARAM_STR);
                $consulta->execute();
                $respuesta = array("Estado" => "OK", "Mensaje" => "Usuario registrado correctamente.");
            
        
        } catch (Exception $e) {
            $mensaje = $e->getMessage();
            $respuesta = array("Estado" => "ERROR", "Mensaje" => "$mensaje");
        } finally {
            return $respuesta;
        }
    }

    public static function Login($legajo, $clave)
    {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
      

     $consulta1 = $objetoAccesoDato->RetornarConsulta("SELECT * FROM usuarios as u
                                                                    WHERE u.legajo = :legajo");
     $consulta1->execute(array(":legajo" => $legajo));
            
    $resultado = $consulta1->fetchObject('Usuario');
        
        return $resultado;
    }

    public static function Listar()
    {
        try {
            $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();

            $consulta = $objetoAccesoDato->RetornarConsulta("SELECT id_user, nombre, sexo, perfil from usuarios");

            $consulta->execute();

            $respuesta = $consulta->fetchAll(PDO::FETCH_CLASS, "Usuario");
        } catch (Exception $e) {
            $mensaje = $e->getMessage();
            $respuesta = array("Estado" => "ERROR", "Mensaje" => "$mensaje");
        }
        finally {
            return $respuesta;
        }
    }

    
    public static function Modificar($legajo, $email, $foto = null, $token,$id_materia = null)
    {
        try {
            $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
            $payload = Token::ObtenerPayload($token);
            
            if ($legajo != null ) {
                if( $payload->tipo == 'alumno'){
                $consulta = $objetoAccesoDato->RetornarConsulta("UPDATE usuarios set email = :email
                                                                WHERE legajo = :legajo");
                $consulta->bindValue(':email', $email, PDO::PARAM_STR);
               // $consulta->bindValue(':foto', $foto, PDO::PARAM_STR);
                }
               
             else if($payload->tipo == 'profesor')
             {
                $consulta = $objetoAccesoDato->RetornarConsulta("INSERT INTO materiaprofesor (id_materia, legajo) 
                VALUES (:id_materia, :legajo);");   
                 $consulta = $objetoAccesoDato->RetornarConsulta("UPDATE usuarios set email = :email
                 WHERE legajo = :legajo");

                $consulta->bindValue(':email', $email, PDO::PARAM_STR);
                $consulta->bindValue(':id_materia', $id_materia, PDO::PARAM_INT);
                $consulta->bindValue(':legajo', $legajo, PDO::PARAM_INT);




             }
            /* else if($payload->tipo == 'admin'){




             }*/
                $consulta->execute();
                $respuesta = array("Estado" => "OK", "Mensaje" => "Usuario modificado correctamente.");
            } else {
                $respuesta = array("Estado" => "ERROR", "Mensaje" => "Debe ingresar un legajo de usuario valido");
            }
        } catch (Exception $e) {
            $mensaje = $e->getMessage();
            $respuesta = array("Estado" => "ERROR", "Mensaje" => "$mensaje");
        } finally {
            return $respuesta;
        }
    }


    
    public static function Inscripcion($token,$id_materia)
    {
        try {
            $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
            $payload = Token::ObtenerPayload($token);
            $legajo = $payload->legajo;
            if ($legajo != null ) 
            {
                if( $payload->tipo == 'alumno')
                {

                    $consulta = $objetoAccesoDato->RetornarConsulta("SELECT cupos from materias 
                                                                     WHERE id_materia = :id_materia");
                    $consulta->execute();
                    $cupo = $consulta->fetch();
                if($cupo > 0)
                {


                     $consulta = $objetoAccesoDato->RetornarConsulta("UPDATE usuarios set id_materia = :id_materia
                                                                     WHERE legajo = :legajo");
                     $consulta->bindValue(':id_materia', $id_materia, PDO::PARAM_STR);
                     $consulta->execute();

                }
               
                }
               
           
                $respuesta = array("Estado" => "OK", "Mensaje" => "Inscripcion ok");
            } 
            else 
            {
                $respuesta = array("Estado" => "ERROR", "Mensaje" => "Debe ingresar un legajo de usuario valido");
            }
        } catch (Exception $e) {
            $mensaje = $e->getMessage();
            $respuesta = array("Estado" => "ERROR", "Mensaje" => "$mensaje");
        } finally {
            return $respuesta;
        }
    }


}
