<?php
//include_once("usuario.php");
include_once("/pizza.php");
include_once("/archivo.php");

$archivoVentas = new Archivo("venta.txt");
$archivoPizzas = new Archivo("pizza.txt");

if (isset($_POST["caso"]) && !empty($_POST["caso"])) {
    $caso = $_POST["caso"];
    switch ($caso) {
       
        case "altaVenta":
        $email = $_POST["email"];
        $sabor = $_POST["sabor"];
        $tipo = $_POST["tipo"];
        $cantidad = $_POST["cantidad"];
      
       if(Count($arrayVentas) == 0)
        {
            $id = 0;
        }
        else
        {
            for($i = 0; $i<Count($arrayVentas); $i++)
            {
                $id = $i+1;
            }
        }
        
            $registroMateria = $archivoPizzas->obtenerRegistro1("-",$sabor,$tipo,3,1,6);
            $arrayVentas = $archivoVentas->fileToArray();
            if(Count($registroMateria) > 0){
            $registroMateria = explode("-",$registroMateria);     
            $cupo = $registroMateria[4];
            $idPizza = $registroMateria[0];   
            $precio = $registroMateria[2]; 
            if($cupo > 0){


                $venta = new Venta($email,$id,$sabor,$tipo,$cantidad);
                $archivoVentas->Cargar($venta);
                //Bajo 1 el cupo
                $materiaModificada = new Pizza($idPizza,$tipo,$precio, $foto,$sabor,$cupo-$cantidad);
                $archivoPizzas->Modificar("-",$idPizza,0,6,$materiaModificada);    
            }
            else{
                echo "No hay stock";
            }
        }
        else{
            echo "No existe la pizza";
        }
      
     
        
    break;


        case "PizzaCarga":
           // $id = $_POST["id"];
            $tipo = $_POST["tipo"];
            $precio = $_POST["precio"];
            $foto = $_FILES["foto"];
            $sabor = $_POST["sabor"];
            $cantidad = $_POST["cantidad"];
            $arrayPizzas = $archivoPizzas->fileToArray();
            if(Count($arrayPizzas) == 0)
            {
                $id = 0;
            }
            else
            {
                for($i = 0; $i<Count($arrayPizzas); $i++)
                {
                    $id = $i+1;
                }
            }
            $pizza = new Pizza($id, $tipo, $precio, $foto, $sabor, $cantidad);

if( (strcmp($tipo, "molde") == 0  || strcmp($tipo, "piedra") == 0 ))
{
    if(strcmp($sabor, "muzza") == 0  || strcmp($sabor, "jamon") == 0  || strcmp($sabor, "especial") == 0  ) 
    {
        $arrayPizzas1 = $archivoPizzas->obtenerArrayRegistros1("-", strtolower($sabor), $tipo, 4, 2, 6);
        if(Count($arrayPizzas1) != 0)
        {
            echo("Ingrese tipo y sabor sin repetir");
        }
        else
        {
              $archivoPizzas->Cargar($pizza);
            echo("carga ok");
        }

          
    }
 }

else
{
    echo("Ingrese campos validos");
}


            break;

}
} else if (isset($_GET["caso"]) && !empty($_GET["caso"])) {
    $caso = $_GET["caso"];
    switch ($caso) {
    

            case "PizzaConsultar":
            $arrayPizzas = array();
             $arrayPizzas = $archivoPizzas->obtenerArrayRegistros1("-", strtolower($_GET["sabor"]), $_GET["tipo"], 3, 1, 6);

            
    
            if (Count($arrayPizzas) != 0) {
                echo "<br/>Si hay";
                
            }
            else
            {
                echo("No existe el sabor o tipo ".$_GET["sabor"].$_GET["tipo"]);
            }
        break;

        default:
            echo "Debe establecer un caso válido.";
            break;
    }
} else {
    echo "Debe establecer un caso.";
}
