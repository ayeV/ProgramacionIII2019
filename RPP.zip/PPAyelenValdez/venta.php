<?php
    class Venta{
        public $email;
        public $id;
        public $sabor;
        public $tipo;
        public $cantidad;
        public $precio;



        function __construct($email,$id,$sabor,$tipo,$cantidad){
            $this->email = $email;
            $this->id = $id;
            $this->sabor = $sabor;
            $this->tipo = $tipo;
            $this->cantidad = $cantidad;



        }

        public function __toString(){
            return $this->id."-".$this->email."-".$this->sabor."-".$this->tipo."-".$this->cantidad.PHP_EOL; 
        } 


     
    }
?>