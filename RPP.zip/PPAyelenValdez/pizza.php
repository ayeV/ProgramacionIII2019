<?php
    class Pizza
    {
        public $id;
        public $tipo;
        public $precio;
        public $foto;
        public $cantidad;
        public $sabor;


        function __construct($id,$tipo,$precio, $foto,$sabor,$cantidad){
            $this->id = $id;
            $this->tipo = $tipo;
            $this->precio = $precio;
            $this->foto = $foto;
            $this->sabor = $sabor;
            $this->cantidad = $cantidad;

            //Divide el nombre de la foto en cada punto. Lo revierte para que la extensión quede en el índice cero. 
            $ext = array_reverse(explode(".",$foto["name"]));
            $this->foto = $this->id.".".$ext[0];    
            //Carga la foto.
            Archivo::cargar_imagen($foto["tmp_name"], $this->foto);
        }

        public function __toString(){
            return $this->id."-".$this->tipo."-".$this->precio."-".$this->sabor."-".$this->cantidad."-".$this->foto.PHP_EOL; 
        }

    }

    
?>